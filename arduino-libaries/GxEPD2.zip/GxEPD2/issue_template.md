## Please post only issues that are real issues with this library!
- please use the Arduino Forum Displays for questions or enhancement suggestions

### Expected Behavior

### Actual Behavior

### E-Paper module used

### Arduino / Processor module used

### Steps to reproduce the behavior or reduced but complete code example
