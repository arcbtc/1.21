// ArduinoJson - arduinojson.org
// Copyright Benoit Blanchon 2014-2019
// MIT License

#define CATCH_CONFIG_MAIN
#include "catch.hpp"
